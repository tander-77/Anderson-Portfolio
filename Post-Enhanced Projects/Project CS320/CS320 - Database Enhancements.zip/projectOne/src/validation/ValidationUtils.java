package validation;

/** 
* Shared validation helper methods for the CS320 services.
* 
* Centralizing these checks keeps the code consistent and easier to maintain.
*/

public final class ValidationUtils {
	
	// private constructor to prevent instantiation (utility class pattern)
	private ValidationUtils() { }
	
	/**
	 * Validated that a String is not null, not empty/blank,
	 * and does not exceed a maximum length.
	 * 
	 * @param value      the value to validate
	 * @param maxLength  maximum allowed length
	 * @param fieldName  user-friendly name for error message
	 */
	public static void requireNonNullAndMaxLength(String value, int maxLength, String fieldName) {
		if (value == null || value.trim().isEmpty()) {
			throw new ValidationException(fieldName + " cannot be null or empty.");
		}
		if (value.length() > maxLength) {
			throw new ValidationException(fieldName + " cannot exceed " + maxLength + " characters.");
		}
	}
	
	/**
	 * Validates that a String is exactly a given length and consists only of digits.
	 * Useful for phone numbers, IDs, etc.
	 * 
	 * @param value      the value to validate
	 * @param length     required length
	 * @param fieldName  user-friendly name for error messages
	 */
	public static void requireExactLengthDigits(String value, int length, String fieldName) {
		if (value == null) {
			throw new ValidationException(fieldName + " cannot be null.");
		}
		if (value.length() != length) {
			throw new ValidationException(fieldName + " must be exactly " + length + " digits.");
		}
		for (int i = 0; i < value.length(); i++) {
			if (!Character.isDigit(value.charAt(i))) {
				throw new ValidationException(fieldName + " must contain only numeric digits.");
			}
		}
	}
}
