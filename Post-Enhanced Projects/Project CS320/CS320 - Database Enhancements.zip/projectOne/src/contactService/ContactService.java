package contactService;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import validation.ValidationException;
import validation.ValidationUtils;

/**
 * Service layer for managing Contact objects.
 *
 * This class simulates a database table using a Map keyed by contactId.
 * It centralizes CRUD-style operations and enforces validation and
 * uniqueness rules, which prepares the design for future integration
 * with a real database such as MongoDB.
 */
public class ContactService {

    // In-memory "Contact table" keyed by contactId
    private final Map<String, Contact> contactStore = new HashMap<>();

    /**
     * Adds a new Contact record.
     *
     * @param contactId unique identifier for the contact
     * @param firstName first name
     * @param lastName  last name
     * @param phone     phone number (10 digits)
     * @param address   street address
     * @return the created Contact
     * @throws ValidationException if the ID already exists or fields are invalid
     */
    public Contact addContact(String contactId, String firstName, String lastName, String phone, String address) {
        // Validate ID first for clarity
        ValidationUtils.requireNonNullAndMaxLength(contactId, 10, "Contact ID");

        synchronized (contactStore) {
            if (contactStore.containsKey(contactId)) {
                throw new ValidationException("Contact with ID '" + contactId + "' already exists.");
            }

            // Contact constructor validates all other fields
            Contact newContact = new Contact(contactId, firstName, lastName, phone, address);
            contactStore.put(contactId, newContact);
            return newContact;
        }
    }

    /**
     * Backwards-compatible overload that accepts a Contact object.
     * Delegates to the newer addContact(String, String, String, String, String) method.
     */
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new ValidationException("Contact cannot be null.");
        }
        addContact(
                contact.getContactId(),
                contact.getFirstName(),
                contact.getLastName(),
                contact.getPhone(),
                contact.getAddress()
        );
    }

    /**
     * Backwards-compatible method name used by older tests.
     * Delegates to getContact(String).
     */
    public Contact getContactById(String contactId) {
        return getContact(contactId);
    }

    /**
     * Deletes a Contact by its ID.
     *
     * @param contactId ID of the contact to delete
     * @throws ValidationException if the ID is invalid or contact does not exist
     */
    public void deleteContact(String contactId) {
        ValidationUtils.requireNonNullAndMaxLength(contactId, 10, "Contact ID");

        synchronized (contactStore) {
            if (contactStore.remove(contactId) == null) {
                throw new ValidationException("Contact with ID '" + contactId + "' does not exist.");
            }
        }
    }

    /**
     * Updates the first name of an existing Contact.
     */
    public void updateFirstName(String contactId, String newFirstName) {
        ValidationUtils.requireNonNullAndMaxLength(contactId, 10, "Contact ID");
        ValidationUtils.requireNonNullAndMaxLength(newFirstName, 10, "First name");

        synchronized (contactStore) {
            Contact existing = contactStore.get(contactId);
            if (existing == null) {
                throw new ValidationException("Contact with ID '" + contactId + "' does not exist.");
            }
            existing.setFirstName(newFirstName);
        }
    }

    /**
     * Updates the last name of an existing Contact.
     */
    public void updateLastName(String contactId, String newLastName) {
        ValidationUtils.requireNonNullAndMaxLength(contactId, 10, "Contact ID");
        ValidationUtils.requireNonNullAndMaxLength(newLastName, 10, "Last name");

        synchronized (contactStore) {
            Contact existing = contactStore.get(contactId);
            if (existing == null) {
                throw new ValidationException("Contact with ID '" + contactId + "' does not exist.");
            }
            existing.setLastName(newLastName);
        }
    }

    /**
     * Updates the phone number of an existing Contact.
     */
    public void updatePhone(String contactId, String newPhone) {
        ValidationUtils.requireNonNullAndMaxLength(contactId, 10, "Contact ID");
        // Phone has its own digit/length rule
        ValidationUtils.requireExactLengthDigits(newPhone, 10, "Phone");

        synchronized (contactStore) {
            Contact existing = contactStore.get(contactId);
            if (existing == null) {
                throw new ValidationException("Contact with ID '" + contactId + "' does not exist.");
            }
            existing.setPhone(newPhone);
        }
    }

    /**
     * Updates the address of an existing Contact.
     */
    public void updateAddress(String contactId, String newAddress) {
        ValidationUtils.requireNonNullAndMaxLength(contactId, 10, "Contact ID");
        ValidationUtils.requireNonNullAndMaxLength(newAddress, 30, "Address");

        synchronized (contactStore) {
            Contact existing = contactStore.get(contactId);
            if (existing == null) {
                throw new ValidationException("Contact with ID '" + contactId + "' does not exist.");
            }
            existing.setAddress(newAddress);
        }
    }
    
    /**
     * Backwards-compatible method used by older tests.
     * Accepts a full Contact object and applies its fields
     * to the existing stored contact with the same ID.
     */
    public void updateContact(Contact contact) {
        if (contact == null) {
            throw new ValidationException("Contact cannot be null.");
        }

        String contactId = contact.getContactId();
        ValidationUtils.requireNonNullAndMaxLength(contactId, 10, "Contact ID");

        synchronized (contactStore) {
            Contact existing = contactStore.get(contactId);
            if (existing == null) {
                throw new ValidationException("Contact with ID '" + contactId + "' does not exist.");
            }

            // Reuse setters so validation rules still apply
            existing.setFirstName(contact.getFirstName());
            existing.setLastName(contact.getLastName());
            existing.setPhone(contact.getPhone());
            existing.setAddress(contact.getAddress());
        }
    }
    
    /**
     * Backwards-compatible update method used by older tests.
     * Updates all fields based on individual parameters.
     */
    public void updateContact(String contactId,
                              String newFirstName,
                              String newLastName,
                              String newPhone,
                              String newAddress) {

        ValidationUtils.requireNonNullAndMaxLength(contactId, 10, "Contact ID");
        ValidationUtils.requireNonNullAndMaxLength(newFirstName, 10, "First name");
        ValidationUtils.requireNonNullAndMaxLength(newLastName, 10, "Last name");
        ValidationUtils.requireExactLengthDigits(newPhone, 10, "Phone");
        ValidationUtils.requireNonNullAndMaxLength(newAddress, 30, "Address");

        synchronized (contactStore) {
            Contact existing = contactStore.get(contactId);
            if (existing == null) {
                throw new ValidationException("Contact with ID '" + contactId + "' does not exist.");
            }

            existing.setFirstName(newFirstName);
            existing.setLastName(newLastName);
            existing.setPhone(newPhone);
            existing.setAddress(newAddress);
        }
    }



    /**
     * Retrieves a single Contact by ID.
     *
     * @param contactId ID to look up
     * @return the Contact if found, or null if not found
     * @throws ValidationException if the ID is invalid
     */
    public Contact getContact(String contactId) {
        ValidationUtils.requireNonNullAndMaxLength(contactId, 10, "Contact ID");
        synchronized (contactStore) {
            return contactStore.get(contactId);
        }
    }

    /**
     * Returns a read-only snapshot of all contacts.
     */
    public Map<String, Contact> getAllContacts() {
        synchronized (contactStore) {
            return Collections.unmodifiableMap(new HashMap<>(contactStore));
        }
    }

    /**
     * Clears all contacts. Primarily useful for unit tests.
     */
    public void clearAll() {
        synchronized (contactStore) {
            contactStore.clear();
        }
    }
}
