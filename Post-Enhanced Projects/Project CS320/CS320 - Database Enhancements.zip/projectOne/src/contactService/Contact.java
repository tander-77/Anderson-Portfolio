package contactService;

import validation.ValidationUtils;

/**
 * Represents a Contact record in the system
 *
 * Typical CS320 constraints (kept here):
 * - contactId: non-null, max 10 chars
 * - firstName: non-null, max 10 chars
 * - lastName:  non-null, max 10 chars
 * - phone:     exactly 10 numeric digits
 * - address:   non-null, max 30 chars
 * 
 * The constructor and setters enforce these rules to ensure the
 * Contact object cannot exist in an invalid state.
 */
public class Contact {
	
	private String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	/**
	 * Constructs a new Contact with all required fields
	 */
	public Contact(String contactId, String firstName, String lastName, String phone, String address) {
		// Validate ID and text fields
		ValidationUtils.requireNonNullAndMaxLength(contactId, 10, "Contact ID");
		ValidationUtils.requireNonNullAndMaxLength(firstName, 10, "First name");
		ValidationUtils.requireNonNullAndMaxLength(lastName, 10, "Last name");
		ValidationUtils.requireNonNullAndMaxLength(phone, 10, "Phone");
		ValidationUtils.requireNonNullAndMaxLength(address, 30, "Address");
		
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}
	
	// --- Getters ---
	
	public String getContactId() {
		return contactId;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	// --- Setters (no setter for contactId to keep it stable) ---
	
	public void setFirstName(String firstName) {
		ValidationUtils.requireNonNullAndMaxLength(firstName, 10, "First name");
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		ValidationUtils.requireNonNullAndMaxLength(lastName, 10, "Last name");
		this.lastName = lastName;
	}
	
	public void setPhone(String phone) {
		ValidationUtils.requireNonNullAndMaxLength(phone, 10, "Phone");
		this.phone = phone;
	}
	
	public void setAddress(String address) {
		ValidationUtils.requireNonNullAndMaxLength(address, 30, "Address");
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "Contact{" +
				"contactId='" + contactId + '\'' +
				", firstName='" + firstName + '\''+
				", lastName='" + lastName + '\'' +
				", phone='" + phone + '\'' +
				", address='" + address + '\'' +
				'}';
	}
}