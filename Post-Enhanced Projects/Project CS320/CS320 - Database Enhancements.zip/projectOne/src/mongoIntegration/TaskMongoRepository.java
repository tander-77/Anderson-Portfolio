package mongoIntegration;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;

import taskService.Task;

/**
 * MongoDB-backed repository for Task records.
 * 
 * This class demonstrates how the existing Task domain model
 * could be persisted in a real database. It uses MongoDB as 
 * the backing store instead of the in-memory Map used by 
 * TaskService.
*/
public class TaskMongoRepository implements AutoCloseable {
	
	private final MongoClient client;
	private final MongoCollection<Document> collection;
	
	/**
	 * Creates a new repository for Tasks using MongoDB.
	 * 
	 * @param connectionString 
	 * @param databaseName 
	 * @param collectionName 
	 */
	public TaskMongoRepository(String connectionString, String databaseName, String collectionName) {
		this.client = MongoClients.create(connectionString);
		MongoDatabase db = client.getDatabase(databaseName);
		this.collection = db.getCollection(collectionName);
	}
	
	/**
	 * Inserts a new Task into the MongoDB collection.
	 * Uses taskId as the MongoDB _id field to enforce uniqueness.
	 */
	public void insertTask(Task task) {
		Document doc = new Document("_id", task.getTaskId())
				.append("name", task.getName())
				.append("description", task.getDescription());
		collection.insertOne(doc);
	}
	
	/**
	 * Finds a Task by its ID. Returns null if not found.
	 */
	public Task findById(String taskId) {
		Document doc = collection.find(Filters.eq("_id", taskId)).first();
		if (doc == null) {
			return null;
		}
		return new Task(
				doc.getString("_id"),
				doc.getString("name"),
				doc.getString("description")
		);
	}
	
	/**
	 * Updates an existing Task in MongoDB by replacing its
	 * name and description fields based on the current Task object.
	 */
	public void updateTask(Task task) {
		Document update = new Document("$set",
				new Document("name", task.getName())
					.append("description", task.getDescription())
		);
		collection.updateOne(Filters.eq("_id", task.getTaskId()), update);
	}
	
	/**
	 * Deletes a Task from MongoDB by its ID.
	 */
	public void deleteById(String taskId) {
		collection.deleteOne(Filters.eq("_id", taskId));
	}
	
	/**
	 * Closes the underlying MongoClient. Call this when 
	 * done using the repository.
	 */
	@Override
	public void close() {
		client.close();
	}
}
