package appointmentService;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import validation.ValidationException;
import validation.ValidationUtils;

/**
 * Service layer for managing Appointment objects.
 *
 * This class simulates a database table using a Map keyed by appointmentId.
 * It centralizes CRUD-style operations and enforces validation and
 * uniqueness rules, preparing the design for future integration
 * with a real database such as MongoDB.
 */
public class AppointmentService {

    // In-memory "Appointment table" keyed by appointmentId
    private final Map<String, Appointment> appointmentStore = new HashMap<>();

    /**
     * Adds a new Appointment record.
     *
     * @param appointmentId unique identifier for the appointment
     * @param date          appointment date (must not be null or in the past)
     * @param description   description of the appointment
     * @return the created Appointment
     * @throws ValidationException if the ID already exists or fields are invalid
     */
    public Appointment addAppointment(String appointmentId, Date date, String description) {
        ValidationUtils.requireNonNullAndMaxLength(appointmentId, 10, "Appointment ID");

        synchronized (appointmentStore) {
            if (appointmentStore.containsKey(appointmentId)) {
                throw new ValidationException("Appointment with ID '" + appointmentId + "' already exists.");
            }

            // Appointment constructor validates date and description
            Appointment newAppointment = new Appointment(appointmentId, date, description);
            appointmentStore.put(appointmentId, newAppointment);
            return newAppointment;
        }
    }

    /**
     * Backwards-compatible overload that accepts an Appointment object.
     * Delegates to the newer addAppointment(String, Date, String) method.
     */
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new ValidationException("Appointment cannot be null.");
        }
        addAppointment(
                appointment.getAppointmentId(),
                appointment.getAppointmentDate(),
                appointment.getDescription()
        );
    }

    /**
     * Backwards-compatible method name used by older tests.
     * Delegates to getAppointment(String).
     */
    public Appointment getAppointmentById(String appointmentId) {
        return getAppointment(appointmentId);
    }

    /**
     * Deletes an Appointment by its ID.
     *
     * @param appointmentId ID of the appointment to delete
     * @throws ValidationException if the ID is invalid or appointment does not exist
     */
    public void deleteAppointment(String appointmentId) {
        ValidationUtils.requireNonNullAndMaxLength(appointmentId, 10, "Appointment ID");

        synchronized (appointmentStore) {
            if (appointmentStore.remove(appointmentId) == null) {
                throw new ValidationException("Appointment with ID '" + appointmentId + "' does not exist.");
            }
        }
    }

    /**
     * Updates the description of an existing Appointment.
     *
     * @param appointmentId  ID of the appointment to update
     * @param newDescription new description
     * @throws ValidationException if the appointment does not exist or description is invalid
     */
    public void updateDescription(String appointmentId, String newDescription) {
        ValidationUtils.requireNonNullAndMaxLength(appointmentId, 10, "Appointment ID");
        ValidationUtils.requireNonNullAndMaxLength(newDescription, 50, "Description");

        synchronized (appointmentStore) {
            Appointment existing = appointmentStore.get(appointmentId);
            if (existing == null) {
                throw new ValidationException("Appointment with ID '" + appointmentId + "' does not exist.");
            }
            existing.setDescription(newDescription);
        }
    }

    /**
     * Updates the date of an existing Appointment.
     *
     * @param appointmentId ID of the appointment to update
     * @param newDate       new appointment date (must not be in the past)
     * @throws ValidationException if the appointment does not exist or date is invalid
     */
    public void updateDate(String appointmentId, Date newDate) {
        ValidationUtils.requireNonNullAndMaxLength(appointmentId, 10, "Appointment ID");

        synchronized (appointmentStore) {
            Appointment existing = appointmentStore.get(appointmentId);
            if (existing == null) {
                throw new ValidationException("Appointment with ID '" + appointmentId + "' does not exist.");
            }
            existing.setAppointmentDate(newDate);
        }
    }

    /**
     * Retrieves a single Appointment by ID.
     *
     * @param appointmentId ID to look up
     * @return the Appointment if found, or null if not found
     * @throws ValidationException if the ID is invalid
     */
    public Appointment getAppointment(String appointmentId) {
        ValidationUtils.requireNonNullAndMaxLength(appointmentId, 10, "Appointment ID");
        synchronized (appointmentStore) {
            return appointmentStore.get(appointmentId);
        }
    }

    /**
     * Returns a read-only snapshot of all appointments.
     */
    public Map<String, Appointment> getAllAppointments() {
        synchronized (appointmentStore) {
            return Collections.unmodifiableMap(new HashMap<>(appointmentStore));
        }
    }

    /**
     * Clears all appointments. Primarily useful for unit tests.
     */
    public void clearAll() {
        synchronized (appointmentStore) {
            appointmentStore.clear();
        }
    }
}
