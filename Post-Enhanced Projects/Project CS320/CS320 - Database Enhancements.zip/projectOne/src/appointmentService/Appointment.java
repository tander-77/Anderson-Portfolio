package appointmentService;

import java.util.Date;

import validation.ValidationException;
import validation.ValidationUtils;

/**
 * Represents an Appointment record in the system. 
 * 
 * Typical CS320 constraints:
 * - appointmentId:   non-null, max 10 chars
 * - description:     non-null, max 50 chars
 * - appointmentDate: non-null and not in the past 
 * 
 * The constructor and setters enforce these rules to ensure
 * the Appointment object cannot exist in an invalid state.
*/
public class Appointment {
	
	private String appointmentId;
	private String description;
	private Date appointmentDate;
	
	/**
	 * Constructs a new Appointment with all required files.
	 */
	public Appointment(String appointmentId, Date appointmentDate, String description) {
		// Validate ID and description using shared helpers
		ValidationUtils.requireNonNullAndMaxLength(appointmentId, 10, "Appointment ID");
		ValidationUtils.requireNonNullAndMaxLength(description, 50, "Description");
		
		if (appointmentDate == null) {
			throw new ValidationException("Appointment date cannot be null.");
		}
		if (appointmentDate.before(new Date())) {
			throw new ValidationException("Appointment date cannot be in the past.");
		}
		
		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.description = description;
	}
	
	// --- Getters ---
	
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public String getDescription() {
		return description;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	// --- Setters (no setter for appointmentId to keep it stable) ---
	
	public void setDescription(String description) {
		ValidationUtils.requireNonNullAndMaxLength(description, 50, "Description");
		this.description = description;
	}
	
	public void setAppointmentDate(Date appointmentDate) {
		if (appointmentDate == null) {
			throw new ValidationException("Appointment date cannot be null.");
		}
		if (appointmentDate.before(new Date())) {
			throw new ValidationException("Appointment date cannot be in the past.");
		}
		this.appointmentDate = appointmentDate;
	}
	
	@Override
	public String toString() {
		return "Appointment{" +
				"appointmentId='" + appointmentId + '\'' +
				", description='" + description + '\'' +
				", appointmentDate='" + appointmentDate + 
				'}';
	}
}
