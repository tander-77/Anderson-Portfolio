package taskService;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import mongoIntegration.TaskMongoRepository;
import validation.ValidationException;
import validation.ValidationUtils;

/**
 * Service layer for managing Task objects.
 *
 * This class simulates a database table using a Map keyed by taskId.
 * It now also supports optional integration with MongoDB through
 * TaskMongoRepository. If a Mongo repository is provided, operations
 * will write-through to MongoDB in addition to updating the in-memory
 * store.
 */
public class TaskService {

    // In-memory "Task table" keyed by taskId
    private final Map<String, Task> taskStore = new HashMap<>();

    // Optional MongoDB-backed repository (may be null)
    private final TaskMongoRepository mongoRepository;

    /**
     * Default constructor: uses only the in-memory store.
     *
     * This keeps the original CS320 tests working exactly as before.
     */
    public TaskService() {
        this(null);
    }

    /**
     * Constructor that accepts a Mongo-backed repository.
     *
     * When provided, all write operations will also update MongoDB.
     *
     * @param mongoRepository repository to use, or null for in-memory only
     */
    public TaskService(TaskMongoRepository mongoRepository) {
        this.mongoRepository = mongoRepository;
    }

    /**
     * Adds a new Task record.
     *
     * @param taskId      unique identifier for the task
     * @param name        task name
     * @param description task description
     * @return the created Task
     * @throws ValidationException if the ID already exists or fields are invalid
     */
    public Task addTask(String taskId, String name, String description) {
        // Validate ID explicitly first
        ValidationUtils.requireNonNullAndMaxLength(taskId, 10, "Task ID");

        synchronized (taskStore) {
            if (taskStore.containsKey(taskId)) {
                throw new ValidationException("Task with ID '" + taskId + "' already exists.");
            }

            // Task constructor will validate name/description
            Task newTask = new Task(taskId, name, description);
            taskStore.put(taskId, newTask);

            // If Mongo integration is configured, also insert into MongoDB
            if (mongoRepository != null) {
                mongoRepository.insertTask(newTask);
            }

            return newTask;
        }
    }

    /**
     * Backwards-compatible overload used by older tests.
     * Accepts a Task object and delegates to the newer addTask(...) method.
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new ValidationException("Task cannot be null.");
        }
        addTask(task.getTaskId(), task.getName(), task.getDescription());
    }

    /**
     * Backwards-compatible method name used by older tests.
     * Delegates to getTask(String).
     */
    public Task getTaskById(String taskId) {
        return getTask(taskId);
    }

    /**
     * Backwards-compatible method used by older tests.
     * Updates both name and description in one call.
     */
    public void updateTask(String taskId, String newName, String newDescription) {
        ValidationUtils.requireNonNullAndMaxLength(taskId, 10, "Task ID");
        ValidationUtils.requireNonNullAndMaxLength(newName, 20, "Task name");
        ValidationUtils.requireNonNullAndMaxLength(newDescription, 50, "Task description");

        synchronized (taskStore) {
            Task existing = taskStore.get(taskId);
            if (existing == null) {
                throw new ValidationException("Task with ID '" + taskId + "' does not exist.");
            }

            existing.setName(newName);
            existing.setDescription(newDescription);

            // Write-through update to MongoDB if configured
            if (mongoRepository != null) {
                mongoRepository.updateTask(existing);
            }
        }
    }

    /**
     * Deletes a Task by its ID.
     *
     * @param taskId ID of the task to delete
     * @throws ValidationException if the ID is invalid or task does not exist
     */
    public void deleteTask(String taskId) {
        ValidationUtils.requireNonNullAndMaxLength(taskId, 10, "Task ID");

        synchronized (taskStore) {
            Task removed = taskStore.remove(taskId);
            if (removed == null) {
                throw new ValidationException("Task with ID '" + taskId + "' does not exist.");
            }

            // Also delete from MongoDB if configured
            if (mongoRepository != null) {
                mongoRepository.deleteById(taskId);
            }
        }
    }

    /**
     * Updates the name of an existing Task.
     *
     * @param taskId  ID of the task to update
     * @param newName new task name
     * @throws ValidationException if the task does not exist or name is invalid
     */
    public void updateTaskName(String taskId, String newName) {
        ValidationUtils.requireNonNullAndMaxLength(taskId, 10, "Task ID");
        ValidationUtils.requireNonNullAndMaxLength(newName, 20, "Task name");

        synchronized (taskStore) {
            Task existing = taskStore.get(taskId);
            if (existing == null) {
                throw new ValidationException("Task with ID '" + taskId + "' does not exist.");
            }
            existing.setName(newName);

            // Write-through update to MongoDB if configured
            if (mongoRepository != null) {
                mongoRepository.updateTask(existing);
            }
        }
    }

    /**
     * Updates the description of an existing Task.
     *
     * @param taskId         ID of the task to update
     * @param newDescription new task description
     * @throws ValidationException if the task does not exist or description is invalid
     */
    public void updateTaskDescription(String taskId, String newDescription) {
        ValidationUtils.requireNonNullAndMaxLength(taskId, 10, "Task ID");
        ValidationUtils.requireNonNullAndMaxLength(newDescription, 50, "Task description");

        synchronized (taskStore) {
            Task existing = taskStore.get(taskId);
            if (existing == null) {
                throw new ValidationException("Task with ID '" + taskId + "' does not exist.");
            }
            existing.setDescription(newDescription);

            // Write-through update to MongoDB if configured
            if (mongoRepository != null) {
                mongoRepository.updateTask(existing);
            }
        }
    }

    /**
     * Retrieves a single Task by ID from the in-memory store.
     *
     * @param taskId ID to look up
     * @return the Task if found, or null if not found
     * @throws ValidationException if the ID is invalid
     */
    public Task getTask(String taskId) {
        ValidationUtils.requireNonNullAndMaxLength(taskId, 10, "Task ID");
        synchronized (taskStore) {
            return taskStore.get(taskId);
        }
    }

    /**
     * Returns a read-only snapshot of all tasks.
     */
    public Map<String, Task> getAllTasks() {
        synchronized (taskStore) {
            return Collections.unmodifiableMap(new HashMap<>(taskStore));
        }
    }

    /**
     * Clears all tasks from the in-memory store.
     * (Does not clear MongoDB; used primarily for unit tests.)
     */
    public void clearAll() {
        synchronized (taskStore) {
            taskStore.clear();
        }
    }
}
