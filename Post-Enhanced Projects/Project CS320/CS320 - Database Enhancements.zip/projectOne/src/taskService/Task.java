package taskService;

import validation.ValidationUtils;

/**
 * Represents a Task record in system.abstract
 *
 * This version centralizes validation logic and treats the Task as a
 * database-like entity with strong constraints:
 *  - taskId: non-null, max 10 chars
 *  - name:   non-null, max 20 chars
 *  - description: non-null, max 50 chars
 *
 * The constructor and setters both enforce these rules so that the object
 * cannot exist in an invalid state.
 */
public class Task {
	
	private String taskId;
	private String name;
	private String description;
	
	/**
	 * Creates a new Task with the required fields. 
	 */
	public Task(String taskId, String name, String description) {
		// validate all fields using shared helper
		ValidationUtils.requireNonNullAndMaxLength(taskId, 10, "Task ID");
		ValidationUtils.requireNonNullAndMaxLength(name, 20, "Task name");
		ValidationUtils.requireNonNullAndMaxLength(description, 50, "Task description");
		
		this.taskId = taskId;
		this.name = name;
		this.description = description;
	}
	
	// --- Getters ---
	
	public String getTaskId() {
		return taskId;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	// --- Setter (for name and description only) ---
	
	/**
	 * Updates the task name with full validation.
	 */
	public void setName(String name) {
		ValidationUtils.requireNonNullAndMaxLength(name, 20, "Task name");
		this.name = name;
	}
	
	/**
	 * Updates the task description with full validation.
	 */
	public void setDescription(String description) {
		ValidationUtils.requireNonNullAndMaxLength(description, 50, "Task description");
		this.description = description;
	}
	
	// (No setter for taskId - it is intended to be immutable once created.)
	
	@Override
	public String toString() {
		return "Task{" +
				"taskId='" + taskId + '\'' +
				", name='" + name + '\'' +
				", description='" + description + '\'' +
				'}';
	}
}