package com.example.weighttrackingapp_andersontrinity.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Represents a user in the app.
 * Store a salted & hashed password (as Base64 strings),
 * not a raw/plaintext password.
 */
@Entity(
    tableName = "users",
    indices = [Index(value = ["username"], unique = true)]
)
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val username: String,
    val passwordHashB64: String,
    val saltB64: String
)