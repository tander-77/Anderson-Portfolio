package com.example.weighttrackingapp_andersontrinity.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.example.weighttrackingapp_andersontrinity.repo.UserRepository

/**
 * ViewModel responsible for login/auth state
 */
class AuthViewModel(
    private val repo: UserRepository
) : ViewModel() {

    // null = not attempted yet
    private val _loginResult = MutableStateFlow<Result<Boolean>?>(null)
    val loginResult: StateFlow<Result<Boolean>?> = _loginResult

    fun seedDemoUser() {
        viewModelScope.launch {
            runCatching { repo.ensureDemoUser() }
        }
    }

    fun login(username: String, password: String) {
        viewModelScope.launch {
            val trimmed = username.trim()
            if (trimmed.isEmpty() || password.isEmpty()) {
                _loginResult.value = Result.success(false)
                return@launch
            }

            val result = runCatching {
                repo.authenticate(trimmed, password)
            }

            _loginResult.value = result
        }
    }
}