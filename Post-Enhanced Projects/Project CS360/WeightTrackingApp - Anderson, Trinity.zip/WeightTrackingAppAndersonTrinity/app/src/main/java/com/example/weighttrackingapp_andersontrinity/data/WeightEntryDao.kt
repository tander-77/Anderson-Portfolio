package com.example.weighttrackingapp_andersontrinity.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Data access for weight entries.
 */
@Dao
interface WeightEntryDao {

    @Insert
    suspend fun insert(entry: WeightEntryEntity)

    @Delete
    suspend fun delete(entry: WeightEntryEntity)

    // stream of all entries ordered by date (for Compose UI to observe)
    @Query("SELECT * FROM weight_entries ORDER BY dateEpochMillis ASC")
    fun getAllOrdered(): Flow<List<WeightEntryEntity>>

    // one-shot list (algorithms/tests)
    @Query("SELECT * FROM weight_entries ORDER BY dateEpochMillis ASC")
    suspend fun getAllOrderedOnce(): List<WeightEntryEntity>
}