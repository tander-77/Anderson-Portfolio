package com.example.weighttrackingapp_andersontrinity.repo

import com.example.weighttrackingapp_andersontrinity.data.UserDao
import com.example.weighttrackingapp_andersontrinity.data.UserEntity
import com.example.weighttrackingapp_andersontrinity.security.PasswordHasher

/**
 * high-level operations for users:
 * seeding a demo user, registering a user,, and authenticating.
 */
class UserRepository(private val dao: UserDao) {

    suspend fun ensureDemoUser() {
        if (dao.count() == 0) {
            val salt = PasswordHasher.newSalt()
            val hash = PasswordHasher.hash("password".toCharArray(), salt)

            dao.insert(
                UserEntity(
                    username = "demo",
                    passwordHashB64 = PasswordHasher.toBase64(hash),
                    saltB64 = PasswordHasher.toBase64(salt)
                )
            )
        }
    }

    suspend fun register(username: String, password: String) {
        val trimmed = username.trim()
        require(trimmed.isNotEmpty()) { "Username cannot be blank" }
        require(password.length >= 6) { "Password must be at least 6 characters" }

        val salt = PasswordHasher.newSalt()
        val hash = PasswordHasher.hash(password.toCharArray(), salt)

        dao.insert(
            UserEntity(
                username = trimmed,
                passwordHashB64 = PasswordHasher.toBase64(hash),
                saltB64 = PasswordHasher.toBase64(salt)
            )
        )
    }

    suspend fun authenticate(username: String, password: String): Boolean {
        val user = dao.findByUsername(username.trim()) ?: return false
        return PasswordHasher.verify(password.toCharArray(), user.saltB64, user.passwordHashB64)
    }
}