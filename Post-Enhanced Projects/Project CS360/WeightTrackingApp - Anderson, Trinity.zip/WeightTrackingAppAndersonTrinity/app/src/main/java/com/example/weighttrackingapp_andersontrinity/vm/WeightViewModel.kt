package com.example.weighttrackingapp_andersontrinity.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weighttrackingapp_andersontrinity.data.WeightEntryEntity
import com.example.weighttrackingapp_andersontrinity.repo.WeightRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.pow

/**
 * UI state for the weight screen
 */
data class WeightUiState(
    val entries: List<WeightEntryEntity> = emptyList(),
    val errorMessage: String? = null,
    val lastGoalCrossEntry: WeightEntryEntity? = null,

    // === CATEGORY TWO ADDITIONS (ALGORITHMS & DATA STRUCTURES) ===
    val rollingAverage: Float? = null,
    val trendLabel: String? = null,
    val trendSlope: Float? = null
)

/**
 * ViewModel that owns the weight data & goal logic
 */
class WeightViewModel(
    private val repo: WeightRepository
) : ViewModel() {

    private val _goalLbs = MutableStateFlow<Float?>(null)

    private val _state = MutableStateFlow(WeightUiState())
    val state: StateFlow<WeightUiState> = _state

    init {
        repo.observeAll()
            .onEach { list ->
                val sorted = list.sortedBy { it.dateEpochMillis }

                // --- Perform Algorithms Enhancements ---
                val rollingAvg = computeRollingAverage(sorted)
                val (label, slope) = computeTrend(sorted)

                _state.value = _state.value.copy(
                    entries = sorted,
                    rollingAverage = rollingAvg,
                    trendLabel = label,
                    trendSlope = slope
                )
            }
            .launchIn(viewModelScope)
    }

    fun setGoal(goal: Float?) {
        _goalLbs.value = goal
    }

    fun addEntry(dateEpochMillis: Long, weightLbs: Float) {
        viewModelScope.launch {
            runCatching {
                repo.addEntry(dateEpochMillis, weightLbs)
            }.onFailure { e ->
                _state.value = _state.value.copy(errorMessage = e.message)
            }.onSuccess {
                maybeDetectGoalCross(weightLbs)
            }
        }
    }

    fun clearError() {
        _state.value = _state.value.copy(errorMessage = null)
    }

    /**
     * Detects when the user crosses the goal threshold
     */
    private fun maybeDetectGoalCross(currentWeight: Float) {
        val goal = _goalLbs.value ?: return
        val previous = _state.value.entries.lastOrNull()?.weightLbs

        val wasAboveBefore = previous?.let { it > goal } ?: true
        val nowAtOrBelow = currentWeight <= goal

        if (wasAboveBefore && nowAtOrBelow) {
            val last = _state.value.entries.lastOrNull()
            _state.value = _state.value.copy(lastGoalCrossEntry = last)
        }
    }

    // ==================================================================
    // CATEGORY TWO: ALGORITHMS AND DATA STRUCTURES ENHANCEMENTS
    // ==================================================================

    /**
     * computes a 5-point rolling (moving) average
     */
    private fun computeRollingAverage(list: List<WeightEntryEntity>): Float? {
        if (list.size < 2) return null

        // use last 5 items or fewer if not available
        val window = list.takeLast(5).map { it.weightLbs }

        val sum = window.sum()
        return (sum / window.size)
    }

    /**
     * computes a simple linear regression slope to determine weight trend
     *
     * returns:
     *  Pair(label, slope)
     */
    private fun computeTrend(list: List<WeightEntryEntity>): Pair<String?, Float?> {
        if (list.size < 2) return Pair(null, null)

        // x = index, y = weight
        val xs = list.indices.map { it.toFloat() }
        val ys = list.map { it.weightLbs }

        val n = xs.size

        val meanX = xs.average().toFloat()
        val meanY = ys.average().toFloat()

        var numerator = 0f
        var denominator = 0f

        for (i in 0 until n) {
            numerator += (xs[i] - meanX) * (ys[i] - meanY)
            denominator += (xs[i] - meanX).pow(2)
        }

        if (denominator == 0f) return Pair("Stable", 0f)

        val slope = numerator / denominator

        val label = when {
            slope > 0.05f -> "Rising"
            slope < -0.05f -> "Falling"
            else -> "Stable"
        }

        return Pair(label, slope)
    }
}