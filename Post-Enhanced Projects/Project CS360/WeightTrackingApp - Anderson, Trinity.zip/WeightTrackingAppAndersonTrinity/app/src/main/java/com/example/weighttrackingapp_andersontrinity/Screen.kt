package com.example.weighttrackingapp_andersontrinity

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object DataDisplay : Screen("data_display")
    object SmsPermission : Screen("sms_permission")
}