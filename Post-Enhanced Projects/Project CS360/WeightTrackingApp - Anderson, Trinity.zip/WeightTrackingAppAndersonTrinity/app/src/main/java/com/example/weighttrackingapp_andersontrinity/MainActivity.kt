package com.example.weighttrackingapp_andersontrinity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.telephony.SmsManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.weighttrackingapp_andersontrinity.vm.AuthViewModel
import com.example.weighttrackingapp_andersontrinity.vm.VMFactory
import com.example.weighttrackingapp_andersontrinity.vm.WeightViewModel

class MainActivity : ComponentActivity() {

    private val vmFactory by lazy { VMFactory(application) }

    private val authViewModel : AuthViewModel by viewModels { vmFactory }
    private val weightViewModel : WeightViewModel by viewModels { vmFactory }

    // tracked as compose state
    private val smsPermissionGranted = mutableStateOf(false)

    private val smsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        smsPermissionGranted.value = granted
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // make sure there is at least one demo user to log in with
        authViewModel.seedDemoUser()

        setContent {
            val navController = rememberNavController()
            val context = LocalContext.current

            // on first composition, check if SMS permission is already granted
            LaunchedEffect(Unit) {
                smsPermissionGranted.value =
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.SEND_SMS
                    ) == PackageManager.PERMISSION_GRANTED
            }

            MaterialTheme {
                NavHost(
                    navController = navController,
                    startDestination = "login"
                ) {
                    composable("login") {
                        LoginScreen(
                            authVM = authViewModel,
                            onLoginSuccess = {
                                navController.navigate("data") {
                                    popUpTo("login") { inclusive = true }
                                }
                            }
                        )
                    }

                    composable("data") {
                        DataDisplayScreen(
                            vm = weightViewModel,
                            canSendSms = smsPermissionGranted.value,
                            onRequestSmsPermission = {
                                // ask user for permission at runtime
                                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
                            },
                            onOpenAppSettings = {
                                // open system settings so the user can enable SMS manually
                                val intent = Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", packageName, null)
                                )
                                startActivity(intent)
                            }
                        )
                    }
                }
            }
        }
    }
}