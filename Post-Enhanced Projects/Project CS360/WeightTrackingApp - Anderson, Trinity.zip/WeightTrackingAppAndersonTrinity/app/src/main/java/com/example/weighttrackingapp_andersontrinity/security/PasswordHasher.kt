package com.example.weighttrackingapp_andersontrinity.security

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * utility for hashing passwords with PBKDF2 + salt,
 * and verify them later
 */
object PasswordHasher {
    private const val ITERATIONS = 120_000
    private const val KEY_LENGTH = 256 // bits

    fun newSalt(bytes: Int = 16): ByteArray {
        return SecureRandom().generateSeed(bytes)
    }

    fun hash(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }

    fun toBase64(data: ByteArray): String =
        Base64.encodeToString(data, Base64.NO_WRAP)

    fun fromBase64(b64: String): ByteArray =
        Base64.decode(b64, Base64.NO_WRAP)

    fun verify(password: CharArray, saltB64: String, hashB64: String): Boolean {
        val salt = fromBase64(saltB64)
        val expected = fromBase64(hashB64)
        val actual = hash(password, salt)

        if (expected.size != actual.size) return false

        // constant-time comparison to avoid timing attacks
        var diff = 0
        for (i in expected.indices) {
            diff = diff or (expected[i].toInt() xor actual[i].toInt())
        }
        return diff == 0
    }
}