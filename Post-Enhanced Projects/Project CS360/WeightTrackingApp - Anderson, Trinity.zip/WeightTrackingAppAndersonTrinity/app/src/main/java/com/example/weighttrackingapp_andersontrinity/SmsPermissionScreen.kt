package com.example.weighttrackingapp_andersontrinity

import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

@Composable
fun SmsPermissionScreen() {
    val context = LocalContext.current
    val smsPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        if (smsPermissionGranted) {
            Text("SMS Permission Granted!")
        } else {
            Text("SMS Permission Not Granted...")
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    ActivityCompat.requestPermissions(
                        context as android.app.Activity,
                        arrayOf(Manifest.permission.SEND_SMS),
                        0
                    )
                }
            ) {
                Text("Request SMS Permission")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SmsPermissionScreenPreview() {
    SmsPermissionScreen()
}