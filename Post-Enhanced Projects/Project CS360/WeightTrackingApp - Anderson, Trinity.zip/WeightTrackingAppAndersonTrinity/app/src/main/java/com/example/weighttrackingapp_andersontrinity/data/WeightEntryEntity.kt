package com.example.weighttrackingapp_andersontrinity.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a single weight entry.
 * Store the date as epoch millis so it can be sorted and
 * converted to LocalDate in the UI.
 */
@Entity(tableName = "weight_entries")
data class WeightEntryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val dateEpochMillis: Long,
    val weightLbs: Float
)