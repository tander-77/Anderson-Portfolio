package com.example.weighttrackingapp_andersontrinity

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class WeightDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "WeightDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE weights (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "date TEXT," +
                    "weight TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS weights")
        onCreate(db)
    }

    fun addWeightEntry(date: String, weight: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("date", date)
            put("weight", weight)
        }
        return db.insert("weights", null, values) != -1L
    }

    fun getAllEntries(): List<WeightEntry> {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM weights", null)
        val entries = mutableListOf<WeightEntry>()
        while (cursor.moveToNext()) {
            val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
            val date = cursor.getString(cursor.getColumnIndexOrThrow("date"))
            val weight = cursor.getString(cursor.getColumnIndexOrThrow("weight"))
            entries.add(WeightEntry(id, date, weight))
        }
        cursor.close()
        return entries
    }

    fun updateEntry(id: Int, newDate: String, newWeight: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("date", newDate)
            put("weight", newWeight)
        }
        return db.update("weights", values, "id = ?", arrayOf(id.toString())) > 0
    }

    fun deleteEntry(id: Int): Boolean {
        val db = writableDatabase
        return db.delete("weights", "id = ?", arrayOf(id.toString())) > 0
    }
}