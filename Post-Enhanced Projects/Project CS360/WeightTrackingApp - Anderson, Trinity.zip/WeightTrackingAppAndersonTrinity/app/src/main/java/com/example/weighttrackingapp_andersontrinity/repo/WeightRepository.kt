package com.example.weighttrackingapp_andersontrinity.repo

import kotlinx.coroutines.flow.Flow
import com.example.weighttrackingapp_andersontrinity.data.WeightEntryDao
import com.example.weighttrackingapp_andersontrinity.data.WeightEntryEntity

/**
 * high-level operations for weight entries
 */
class WeightRepository(private val dao: WeightEntryDao) {

    fun observeAll(): Flow<List<WeightEntryEntity>> =
        dao.getAllOrdered()

    suspend fun addEntry(dateEpochMillis: Long, weightLbs: Float) {
        require(weightLbs > 0f) { " Weight must be positive" }
        dao.insert(
            WeightEntryEntity(
                dateEpochMillis = dateEpochMillis,
                weightLbs= weightLbs
            )
        )
    }

    suspend fun deleteEntry(entry: WeightEntryEntity) {
        dao.delete(entry)
    }

    suspend fun listOnce(): List<WeightEntryEntity> =
        dao.getAllOrderedOnce()
}