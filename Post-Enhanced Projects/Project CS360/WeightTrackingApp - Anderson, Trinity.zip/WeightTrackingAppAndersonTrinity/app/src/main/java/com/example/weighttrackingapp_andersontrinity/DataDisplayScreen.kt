package com.example.weighttrackingapp_andersontrinity

import android.telephony.SmsManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.example.weighttrackingapp_andersontrinity.vm.WeightViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DataDisplayScreen(

    vm: WeightViewModel,
    canSendSms: Boolean,
    onRequestSmsPermission: () -> Unit,
    onOpenAppSettings: () -> Unit
) {
    var weightText by remember { mutableStateOf("") }
    var goalText by remember { mutableStateOf("") }

    val state by vm.state.collectAsState()
    val context = LocalContext.current

    // keep ViewModel's goal value in sync with text
    LaunchedEffect(goalText) {
        vm.setGoal(goalText.toFloatOrNull())
    }

    // when a goal-crossing entry appears and SMS is permitted, send notification
    LaunchedEffect(state.lastGoalCrossEntry, canSendSms) {
        val crossing = state.lastGoalCrossEntry
        if (crossing != null && canSendSms) {
            runCatching {
                val smsManager = context.getSystemService(SmsManager::class.java)

                smsManager?.sendTextMessage(
                    "55511234567",
                    null,
                    "Congrats! You reached your goal weight: ${crossing.weightLbs} lbs!",
                    null,
                    null
                )
            }
        }
    }

    // simple date formatter for displaying history
    val dateFormat = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    }

    Column(
        modifier = Modifier.padding(16.dp)
    ) {
        Text(
            text = "Weight Tracker",
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = weightText,
            onValueChange = { weightText = it },
            label = { Text("Current Weight (lbs)") }
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = goalText,
            onValueChange = { goalText = it },
            label = { Text("Goal Weight (lbs)") }
        )

        Spacer(Modifier.height(8.dp))

        Row {
            Button(onClick = {
                val w = weightText.toFloatOrNull()
                if (w != null) {
                    val millis = System.currentTimeMillis()
                    vm.addEntry(millis, w)
                    weightText = ""
                }
            }) {
                Text("Add Entry")
            }

            Spacer(Modifier.width(12.dp))

            if (!canSendSms) {
                OutlinedButton(onClick = onRequestSmsPermission) {
                    Text("Enable SMS Alerts")
                }
            }
        }

        if (state.errorMessage != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = state.errorMessage!!,
                color = MaterialTheme.colorScheme.error
            )
        }

        Spacer(Modifier.height(12.dp))

        // ====== NEW: SUMMARY AREA FOR ALGORITHMS & DATA STRUCTURES ======
        if (state.rollingAverage != null || state.trendLabel != null || state.trendSlope != null) {
            Text("Summary", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))

            state.trendLabel?.let { label ->
                Text("Trend: $label")
            }

            state.rollingAverage?.let { avg ->
                Text("Rolling average (last few entries): ${"%.1f".format(avg)} lbs")
            }

            state.trendSlope?.let { slope ->
                Text("Trend slope (lbs/change): ${"%.2f".format(slope)}")
            }

            Spacer(Modifier.height(12.dp))
        }
        // ========================================================================================

        Text("History", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))

        LazyColumn {
            items(state.entries) { entry ->
                val dateString = dateFormat.format(Date(entry.dateEpochMillis))
                Text("$dateString  -  ${entry.weightLbs} lbs")
            }
        }

        if (state.lastGoalCrossEntry != null && !canSendSms) {
            Spacer(Modifier.height(12.dp))
            Text(
                "You reached your goal! Grant SMS permission so we can notify you by text next time.",
                style = MaterialTheme.typography.bodyMedium
            )
            OutlinedButton(onClick = onOpenAppSettings) {
                Text("Open app settings")
            }
        }
    }
}