package com.example.weighttrackingapp_andersontrinity.vm

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.weighttrackingapp_andersontrinity.data.AppDatabase
import com.example.weighttrackingapp_andersontrinity.repo.UserRepository
import com.example.weighttrackingapp_andersontrinity.repo.WeightRepository

/**
 *  simple factory to create ViewModels that need repositories
 */
class VMFactory(app: Application) : ViewModelProvider.Factory {

    private val db = AppDatabase.getInstance(app)
    private val userRepo = UserRepository(db.userDao())
    private val weightRepo = WeightRepository(db.weightEntryDao())

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when (modelClass) {
            AuthViewModel::class.java -> AuthViewModel(userRepo) as T
            WeightViewModel::class.java -> WeightViewModel(weightRepo) as T
            else -> throw IllegalArgumentException("Unknown ViewModel ${modelClass.simpleName}")
        }
    }
}